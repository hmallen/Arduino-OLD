

//return values 0: ok, -1: error, 1: nothing , 2: modified
#define OK 0
#define ERR -1 
#define NOTHING 1
#define MODIFIED 2
